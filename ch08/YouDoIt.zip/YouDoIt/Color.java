/*
 * Filename Color.java
 * Written by Divya Rasania
 * Written on 09/11/2023
 */

package ch08.YouDoIt;

enum Color {
    BLACK, BLUE, GREEN, RED, WHITE, YELLOW
};