/*
 * Filename UseDinnerPartyWithContructor.java
 * Written by Divya Rasania
 * Written on 09/13/2023
 */

public class UseDinnerPartyWithContructor {
    public static void main(String[] args) {
        DinnerPartyWithConstructor aDinnerParty = new DinnerPartyWithConstructor();
    }
}
