/*
 * Filename InsuredCarDemo.java
 * Written by Divya Rasania
 * Written on 09/13/2023
 */

import javax.swing.JOptionPane;

public class InsuredCarDemo {
    public static void main(String[] args) {
        InsuredCar myCar = new InsuredCar();
        JOptionPane.showMessageDialog(null, myCar.toString());
    }
}
