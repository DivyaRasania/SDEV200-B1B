/*
 * Filename DemoIncrement.java
 * Written by Divya Rasania
 * Written on 9/7/2023
 */

package ch06.YouDoIt;

public class DemoIncrement {
    public static void main(String[] args) {
        int v = 4;
        int plusPlusV = ++v;
        v = 4;
        int vPlusPlus = v++;

        System.out.println(" v is " + v);
        System.out.println(" ++v is " + plusPlusV);
        System.out.println(" v++ is " + vPlusPlus);

    }
}
