package ch02.YouDoIt;

public class DataDemo {
    public static void main(String[] args) {
        int aWholeNumber = 315;
        final int STATES_IN_US = 50;

        System.out.println("The number is " + aWholeNumber);
        System.out.println("The number of states is " + STATES_IN_US);
    }
}