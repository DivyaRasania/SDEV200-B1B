/*
 * Filename REDemo.java
 * Written by Divya Rasania
 * Written on 9/10/2023
 */

package ch04.YouDoIt;

public class REdemo {
    public static void main(String[] args) {
        RealEstateListing myListing = new RealEstateListing(2,
                250000,
                "1212 Mansion Lane",
                6700);

        myListing.display();
    }
}