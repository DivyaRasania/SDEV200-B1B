package ch01.ProgrammingAssignment;

public class MovieQuoteInfo {
    public static void main(String[] args) {
        // I am from India and I have watch many bollywood movies so I have them in
        // here.
        System.out.println("Quote: Kitne aadmin the?" +
                " Movie: Sholay" +
                " Character: Gabbar Singh" +
                " Year Released: 1975");
        System.out.println("Quote: Bade bade deshon mein aisi choti choti baatein hoti rehti hain, Senorita." +
                " Movie: Dilwale Dulhania Le Jayenge" +
                " Character: Raj Malhotra" +
                " Year Released: 1995");
        System.out.println("Quote: Rishte mein toh hum tumhare baap lagte hain, naam hai Shahenshah." +
                " Movie: Shahenshah" +
                " Character: Vijay" +
                " Year Released: 1988");
        System.out.println("Quote: Har pal yahan jee bhar jiyo, jo hai samaa kal ho naa ho" +
                " Movie: Kal Ho Naa Ho" +
                " Character: Aman Mathur" +
                " Year Released: 2003");
    }
}
