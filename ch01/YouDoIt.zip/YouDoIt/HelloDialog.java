// Filename HelloDialog.java
// Written by Divya Rasania
// Written on 8/24/2023

import javax.swing.JOptionPane;

public class HelloDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, world!");
    }
}