// Written by Divya Rasania by 10/08/2023

public class JHelloDemo {
    public static void main(String[] args) {
        JHelloFrame frame = new JHelloFrame();
        frame.setVisible(true);
    }
}