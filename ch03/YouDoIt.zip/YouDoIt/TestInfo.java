/*
 * Filename TestInfo.java
 * Written by Divya Rasania
 * Written on 8/28/2023
 */

package ch03.YouDoIt;

public class TestInfo {
    public static void main(String[] args) {
        System.out.println("Calling method from another class:");
        ParadiseInfo.displayInfo();
    }
}